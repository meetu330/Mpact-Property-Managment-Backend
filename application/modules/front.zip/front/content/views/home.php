<?php
$CI =& get_instance();
$CI->load->library('session');
$vUsername = $this->session->userdata('vUsername')

?>
<div class="page-header">
<div class="page-header-image"></div>
    <div class="container">
        <div class="col-md-12 content-center">
            <div class="card-plain">
                <form role="form" method="post" action="<?php echo base_url('admin/login/csv_upload_action/');?>" enctype='multipart/form-data'>
                    <div class="header lofg">
                        <h5>CSV Data Upload

                            <?php echo "jjjj".$vUsername; ?>

                        </h5>
                    </div>
                    <div class="input-group">
                        <input type="file" id="image" name="image" value="" class="form-control" placeholder="Select image">
                        <span class="input-group-addon">
                            <i class="zmdi zmdi-account-circle"></i>
                        </span>
                    </div>
                     
                    <div class="footer text-center">
                       <button type="submit" class="btn btn-primary btn-round btn-lg btn-block">UPLOAD</button>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript">
    

</script>